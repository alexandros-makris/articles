/*
-- Query: SELECT * FROM AFDEmp_Project_Individual.users
LIMIT 0, 1000

-- Date: 2019-01-02 21:28
*/
INSERT INTO `users` (`id`,`username`,`password`,`fname`,`lname`,`role`,`status`) VALUES (1,'admin','admin','Alex','Makris','admin','online');
INSERT INTO `users` (`id`,`username`,`password`,`fname`,`lname`,`role`,`status`) VALUES (2,'writer1','1234','Joscha','Bach','writer','offline');
INSERT INTO `users` (`id`,`username`,`password`,`fname`,`lname`,`role`,`status`) VALUES (3,'writer2','1234','Max','Tegmark','writer','offline');
INSERT INTO `users` (`id`,`username`,`password`,`fname`,`lname`,`role`,`status`) VALUES (4,'editor1','1234','Nick','Bostrom','editor','offline');
INSERT INTO `users` (`id`,`username`,`password`,`fname`,`lname`,`role`,`status`) VALUES (5,'editor2','1234','Brad','Mehldau','editor','offline');
