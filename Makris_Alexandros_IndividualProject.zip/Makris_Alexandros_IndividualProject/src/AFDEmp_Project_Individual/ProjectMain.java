

package AFDEmp_Project_Individual;



public class ProjectMain {
   
    
    
    ProjectMain() {
        
    }
    
    
    public static void main(String[] args) {
    
        new Menus().loginMenu();
       
    }
    
    
    
}

